from setuptools import setup

setup(
    name='tokogeko_package',
    version='0.0.1',
    packages=['tokogeko_package'],
    url='',
    license='free',
    author='10035002785',
    author_email='yoshiaki.ishikawa.j6w@densotechno.com',
    description='package for toko_geko application'
)
